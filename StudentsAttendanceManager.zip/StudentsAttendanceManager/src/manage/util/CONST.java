package manage.util;

public interface CONST {

	public String LOGINED  = "logined";
	
}
